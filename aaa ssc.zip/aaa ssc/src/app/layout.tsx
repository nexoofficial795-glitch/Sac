import './globals.css';
import { Home, BookOpen, BarChart2, Settings, PenTool } from 'lucide-react';
import Link from 'next/link';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white min-h-screen pb-20">
        <main className="max-w-md mx-auto p-4">
          {children}
        </main>
        
        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 px-6 py-3 flex justify-between items-center max-w-md mx-auto">
          <Link href="/"><Home size={24} /></Link>
          <Link href="/planner"><BookOpen size={24} /></Link>
          <Link href="/quiz"><PenTool size={24} /></Link>
          <Link href="/stats"><BarChart2 size={24} /></Link>
        </nav>
      </body>
    </html>
  );
}