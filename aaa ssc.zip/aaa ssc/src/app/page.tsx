"use client";
import { useEffect, useState } from 'react';
import { getStorage } from '@/lib/storage';
import { QUOTES } from '@/data/quotes';
import { Trophy, Flame, Target } from 'lucide-react';

export default function Home() {
  const [user, setUser] = useState({ streak: 0, xp: 0, level: 'Beginner' });
  const [quote, setQuote] = useState("");

  useEffect(() => {
    setUser(getStorage('user_data', { streak: 0, xp: 0, level: 'Beginner' }));
    setQuote(QUOTES[Math.floor(Math.random() * QUOTES.length)]);
  }, []);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center pt-4">
        <div>
          <h1 className="text-2xl font-bold">CHSL Smart Planner</h1>
          <p className="text-gray-500 text-sm italic">"{quote}"</p>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm text-center">
          <Flame className="mx-auto text-orange-500" />
          <p className="text-xl font-bold">{user.streak}</p>
          <p className="text-[10px] uppercase text-gray-500">Streak</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm text-center">
          <Trophy className="mx-auto text-yellow-500" />
          <p className="text-xl font-bold">{user.xp}</p>
          <p className="text-[10px] uppercase text-gray-500">XP</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl shadow-sm text-center">
          <Target className="mx-auto text-blue-500" />
          <p className="text-xs font-bold mt-1">{user.level}</p>
          <p className="text-[10px] uppercase text-gray-500">Rank</p>
        </div>
      </div>

      <section className="bg-blue-600 p-5 rounded-3xl text-white">
        <h2 className="font-bold">Today's Goal</h2>
        <p className="text-blue-100 text-sm">Complete 1 Quiz & Review 5 Errors</p>
        <div className="mt-4 bg-blue-500/50 h-2 rounded-full">
          <div className="bg-white h-full rounded-full w-1/3"></div>
        </div>
      </section>
    </div>
  );
}