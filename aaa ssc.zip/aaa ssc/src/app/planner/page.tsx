"use client";
import { useState, useEffect } from 'react';
import { getStorage, setStorage } from '@/lib/storage';

export default function Planner() {
  const [examDate, setExamDate] = useState("");
  const [tasks, setTasks] = useState([
    { id: 1, text: "English Grammar: Tenses", done: false },
    { id: 2, text: "Maths: Percentage Concepts", done: false },
    { id: 3, text: "Reasoning: Blood Relations", done: false },
    { id: 4, text: "Daily Current Affairs", done: false },
  ]);

  useEffect(() => {
    const savedDate = getStorage('exam_date', "");
    if (savedDate) setExamDate(savedDate);
  }, []);

  const toggleTask = (id: number) => {
    const newTasks = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
    setTasks(newTasks);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Study Planner</h1>
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl">
        <label className="text-sm text-gray-500">Set Exam Date</label>
        <input 
          type="date" 
          value={examDate}
          onChange={(e) => {setExamDate(e.target.value); setStorage('exam_date', e.target.value);}}
          className="w-full mt-1 bg-transparent border-b border-gray-200 dark:border-slate-700 p-2"
        />
      </div>

      <div className="space-y-3">
        <h2 className="font-semibold px-1">Daily Tasks</h2>
        {tasks.map(task => (
          <div 
            key={task.id} 
            onClick={() => toggleTask(task.id)}
            className={`p-4 rounded-2xl flex items-center gap-3 transition-all ${task.done ? 'bg-green-100 dark:bg-green-900/30 opacity-60' : 'bg-white dark:bg-slate-800'}`}
          >
            <div className={`w-5 h-5 rounded-full border-2 ${task.done ? 'bg-green-500 border-green-500' : 'border-gray-300'}`} />
            <span className={task.done ? 'line-through' : ''}>{task.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}