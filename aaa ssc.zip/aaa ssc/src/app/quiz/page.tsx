"use client";
import { useState } from 'react';
import { QUESTION_BANK } from '@/data/questions';
import { getStorage, setStorage } from '@/lib/storage';

export default function Quiz() {
  const [step, setStep] = useState(0);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const handleAnswer = (option: string) => {
    const isCorrect = option === QUESTION_BANK[step].correct;
    
    if (isCorrect) {
      setScore(score + 1);
    } else {
      // Save to Error Notebook
      const notebook = getStorage('error_notebook', []);
      if (!notebook.find((q: any) => q.id === QUESTION_BANK[step].id)) {
        notebook.push(QUESTION_BANK[step]);
        setStorage('error_notebook', notebook);
      }
    }

    if (step < QUESTION_BANK.length - 1) {
      setStep(step + 1);
    } else {
      setFinished(true);
      const user = getStorage('user_data', { streak: 1, xp: 0, level: 'Beginner' });
      user.xp += score * 10;
      setStorage('user_data', user);
    }
  };

  if (finished) return (
    <div className="flex flex-col items-center justify-center h-[70vh] text-center">
      <div className="text-6xl mb-4">🎉</div>
      <h2 className="text-2xl font-bold">Quiz Complete!</h2>
      <p className="text-gray-500">You scored {score} out of {QUESTION_BANK.length}</p>
      <button onClick={() => window.location.reload()} className="mt-6 bg-blue-600 text-white px-8 py-3 rounded-full font-bold">Try Again</button>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <span className="text-xs font-bold uppercase tracking-widest text-blue-500">{QUESTION_BANK[step].subject}</span>
        <span className="text-xs text-gray-500">Question {step + 1}/{QUESTION_BANK.length}</span>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-sm min-h-[150px] flex items-center">
        <p className="text-lg font-medium">{QUESTION_BANK[step].q}</p>
      </div>

      <div className="grid gap-3">
        {QUESTION_BANK[step].options.map(opt => (
          <button 
            key={opt}
            onClick={() => handleAnswer(opt)}
            className="w-full p-4 text-left bg-white dark:bg-slate-800 border-2 border-transparent active:border-blue-500 rounded-2xl transition-all"
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}