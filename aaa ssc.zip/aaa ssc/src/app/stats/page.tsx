"use client";
import { useEffect, useState } from 'react';
import { getStorage } from '@/lib/storage';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';

export default function Stats() {
  const [errorCount, setErrorCount] = useState(0);
  
  const data = [
    { subject: 'Math', score: 85 },
    { subject: 'English', score: 60 },
    { subject: 'Reasoning', score: 90 },
    { subject: 'GA', score: 40 },
  ];

  useEffect(() => {
    const notebook = getStorage('error_notebook', []);
    setErrorCount(notebook.length);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Performance Analysis</h1>
      
      <div className="bg-white dark:bg-slate-800 p-4 rounded-3xl h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <XAxis dataKey="subject" axisLine={false} tickLine={false} fontSize={12} />
            <Bar dataKey="score" radius={[10, 10, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={index} fill={entry.score > 70 ? '#22c55e' : '#ef4444'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-red-50 dark:bg-red-900/20 p-5 rounded-3xl border border-red-100 dark:border-red-800">
        <h3 className="text-red-600 font-bold">Error Notebook</h3>
        <p className="text-sm text-red-500">You have {errorCount} questions to review from your mistakes.</p>
        <button className="mt-3 w-full bg-red-600 text-white py-2 rounded-xl text-sm font-bold">Review Mistakes</button>
      </div>
    </div>
  );
}