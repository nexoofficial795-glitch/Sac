"use client";
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, BookText, PenTool, BarChart3 } from 'lucide-react';

export default function BottomNav() {
  const pathname = usePathname();
  
  const navs = [
    { href: '/', icon: Home, label: 'Home' },
    { href: '/planner', icon: BookText, label: 'Plan' },
    { href: '/quiz', icon: PenTool, label: 'Quiz' },
    { href: '/stats', icon: BarChart3, label: 'Stats' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-lg border-t border-gray-200 dark:border-slate-800 flex justify-around items-center py-3 px-2 max-w-md mx-auto">
      {navs.map((nav) => {
        const Icon = nav.icon;
        const isActive = pathname === nav.href;
        return (
          <Link key={nav.href} href={nav.href} className={`flex flex-col items-center gap-1 ${isActive ? 'text-blue-600' : 'text-gray-400'}`}>
            <Icon size={20} strokeWidth={isActive ? 3 : 2} />
            <span className="text-[10px] font-medium">{nav.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}