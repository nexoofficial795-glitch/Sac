// src/data/quotes.ts
export const QUOTES = [
  "Success is the sum of small efforts, repeated day in and day out.",
  "Don't stop until you're proud.",
  "Your limitation—it's only your imagination.",
  "The harder you work for something, the greater you'll feel when you achieve it."
];

// src/data/questions.ts
export const QUESTION_BANK = [
  {
    id: 1,
    subject: "Maths",
    q: "The average of 5 numbers is 20. If each number is multiplied by 2, what is the new average?",
    options: ["20", "40", "10", "30"],
    correct: "40"
  },
  {
    id: 2,
    subject: "English",
    q: "Choose the correct synonym for 'ABANDON'.",
    options: ["Keep", "Forsake", "Support", "Adopt"],
    correct: "Forsake"
  },
  {
    id: 3,
    subject: "Reasoning",
    q: "If 123 = 6, 234 = 9, then 345 = ?",
    options: ["12", "15", "10", "9"],
    correct: "12"
  }
];